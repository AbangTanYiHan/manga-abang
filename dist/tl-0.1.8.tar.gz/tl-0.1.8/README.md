# TL

## Installation
Run in command line:

```commandline
pip3 install tl
```

## Running in the background

```commandline
tl -w <your txt file path>
```

## Usage
z key: page + 1
spacebar key: picture + 1
b key: bubblt + 1
x key: box + 1
t key: text + 1